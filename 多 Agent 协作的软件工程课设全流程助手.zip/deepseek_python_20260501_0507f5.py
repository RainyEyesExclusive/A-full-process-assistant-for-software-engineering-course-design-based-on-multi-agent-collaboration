"""
多Agent协作的软件工程课设全流程助手 (教育演示版)
依赖: openai>=1.0.0
运行前设置环境变量 OPENAI_API_KEY
"""

import os
import json
import time
from dataclasses import dataclass, field
from typing import List, Dict, Any
from openai import OpenAI

# ---------- 配置 ----------
MODEL = "gpt-4o-mini"          # 可换为 gpt-3.5-turbo 等
MAX_RETRIES = 2

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# ---------- 数据结构 ----------
@dataclass
class Message:
    role: str
    content: str

@dataclass
class ProjectContext:
    """在整个流程中传递的共享上下文"""
    initial_idea: str
    requirement_doc: str = ""
    architecture_doc: str = ""
    code: str = ""
    test_cases: str = ""
    review_results: List[str] = field(default_factory=list)
    logs: List[str] = field(default_factory=list)
    total_tokens: int = 0

    def add_log(self, log: str):
        self.logs.append(log)

# ---------- Agent 基类 ----------
class BaseAgent:
    def __init__(self, name: str, system_prompt: str):
        self.name = name
        self.system_prompt = system_prompt
        self.history: List[Message] = []

    def call_llm(self, user_message: str, ctx: ProjectContext) -> str:
        messages = [{"role": "system", "content": self.system_prompt}]
        # 加入历史记录（最近4轮）
        for msg in self.history[-4:]:
            messages.append({"role": msg.role, "content": msg.content})
        messages.append({"role": "user", "content": user_message})

        for attempt in range(MAX_RETRIES + 1):
            try:
                response = client.chat.completions.create(
                    model=MODEL,
                    messages=messages,
                    temperature=0.3,
                    max_tokens=2000,
                )
                content = response.choices[0].message.content
                tokens = response.usage.total_tokens if response.usage else 0
                ctx.total_tokens += tokens
                # 记录历史
                self.history.append(Message(role="user", content=user_message))
                self.history.append(Message(role="assistant", content=content))
                ctx.add_log(f"[{self.name}] 消耗 Token: {tokens}")
                return content
            except Exception as e:
                ctx.add_log(f"[{self.name}] 调用失败 (尝试 {attempt+1}): {str(e)}")
                if attempt == MAX_RETRIES:
                    return f"ERROR: {str(e)}"
                time.sleep(2)
        return ""

# ---------- 五个具体 Agent ----------
class RequirementAgent(BaseAgent):
    def __init__(self):
        super().__init__("需求分析Agent", """你是一位资深需求分析师。请通过多轮对话将用户模糊的项目想法细化为标准的需求文档。
要求：
1. 包含功能需求（FR-xxx）和非功能需求（NFR-xxx）
2. 包含用例图文字描述、用户故事
3. 明确输入输出和边界条件
4. 使用中文输出结构化的需求文档
如果没有更多补充信息，请直接生成最终文档。""")

    def run(self, idea: str, ctx: ProjectContext) -> str:
        # 第一阶段：初步澄清
        clarification = self.call_llm(
            f"学生对项目有这样的初步想法：“{idea}”。请提出3-5个关键澄清问题，帮助完善需求。",
            ctx
        )
        # 模拟学生回答（自动假设回答了“是”或给出典型答案）
        student_answer = "所有问题均按照常规企业应用场景处理，使用典型技术栈，无特殊安全要求。"
        # 第二阶段：生成完整需求文档
        final_doc = self.call_llm(
            f"基于学生的想法：“{idea}”，以及你的澄清问题：\n{clarification}\n学生的回答：{student_answer}\n请生成完整的软件需求规格说明。",
            ctx
        )
        ctx.requirement_doc = final_doc
        return final_doc


class ArchitectureAgent(BaseAgent):
    def __init__(self):
        super().__init__("架构设计Agent", """你是一位软件架构师。根据给定的需求文档，生成系统架构设计文档。
包含：
1. 系统模块划分与职责
2. 数据库E-R图描述（文字）
3. 接口定义（RESTful API列表）
4. 技术栈建议（如Spring Boot + Vue.js + MySQL）
5. 设计模式应用说明
输出需为结构化的中文文档。""")

    def run(self, requirement_doc: str, ctx: ProjectContext) -> str:
        arch = self.call_llm(
            f"请根据以下需求文档设计系统架构：\n{requirement_doc}\n",
            ctx
        )
        ctx.architecture_doc = arch
        return arch


class CodeGeneratorAgent(BaseAgent):
    def __init__(self):
        super().__init__("代码生成Agent", """你是一名高级后端开发工程师。请根据需求文档和架构设计，生成关键代码骨架（Java Spring Boot 或 Python Flask）。
包括：
- 实体类（Entity）
- 控制器（Controller）基础CRUD
- 服务层接口
- 部分核心业务逻辑伪代码
请生成清晰可读的代码块，附上简要注释。""")

    def run(self, requirement_doc: str, architecture_doc: str, ctx: ProjectContext) -> str:
        prompt = f"需求文档：\n{requirement_doc}\n\n架构设计：\n{architecture_doc}\n请生成核心代码骨架。"
        code = self.call_llm(prompt, ctx)
        ctx.code = code
        return code


class TestAgent(BaseAgent):
    def __init__(self):
        super().__init__("测试Agent", """你是一名测试工程师。根据需求和代码，生成单元测试和集成测试用例（使用JUnit或pytest格式）。
需包含：
- 正常路径测试
- 边界条件测试
- 异常处理测试
提供可执行的测试代码片段和测试场景表格。""")

    def run(self, requirement_doc: str, code: str, ctx: ProjectContext) -> str:
        prompt = f"需求文档摘要：\n{requirement_doc[:2000]}\n\n代码：\n{code[:3000]}\n请生成测试用例。"
        tests = self.call_llm(prompt, ctx)
        ctx.test_cases = tests
        return tests


class ReviewAgent(BaseAgent):
    def __init__(self):
        super().__init__("审查Agent", """你是一名代码审查专家。对比需求文档、架构设计和代码实现，找出不一致或缺陷。
对每个问题评级：严重（功能性错误）、轻微（代码风格、注释缺失）。
输出审查报告，包含问题列表、评级和建议修复方案。""")

    def run(self, ctx: ProjectContext) -> List[str]:
        prompt = f"""
需求文档：
{ctx.requirement_doc[:2500]}

架构设计：
{ctx.architecture_doc[:1500]}

实现代码：
{ctx.code[:2500]}

测试用例：
{ctx.test_cases[:1500]}

请进行综合审查，列出所有发现的问题，写明严重程度和建议。
"""
        report = self.call_llm(prompt, ctx)
        # 简单解析出问题列表（实际可用正则）
        issues = [line.strip() for line in report.split("\n") if line.strip().startswith(("-", "问题", "•"))]
        ctx.review_results = issues
        return issues

# ---------- 协作流程控制器 ----------
class CollaborationController:
    def __init__(self):
        self.agents = {
            "requirement": RequirementAgent(),
            "architecture": ArchitectureAgent(),
            "codegen": CodeGeneratorAgent(),
            "test": TestAgent(),
            "review": ReviewAgent(),
        }

    def run_full_pipeline(self, idea: str) -> ProjectContext:
        ctx = ProjectContext(initial_idea=idea)
        print(f"\n{'='*60}")
        print(f"🚀 启动课设全流程助手，初始想法：{idea}")
        print("="*60)

        # 1. 需求分析 (长链推理：多轮澄清)
        print("\n📋 [阶段1] 需求分析Agent工作中...")
        req = self.agents["requirement"].run(idea, ctx)
        print("✅ 需求文档生成完毕\n" + '-'*40)
        print(req[:500] + "..." if len(req) > 500 else req)

        # 2. 架构设计
        print("\n🏗️ [阶段2] 架构设计Agent工作中...")
        arch = self.agents["architecture"].run(req, ctx)
        print("✅ 架构设计完成\n" + '-'*40)
        print(arch[:500] + "..." if len(arch) > 500 else arch)

        # 3. 代码生成
        print("\n💻 [阶段3] 代码生成Agent工作中...")
        code = self.agents["codegen"].run(req, arch, ctx)
        print("✅ 代码骨架已生成\n" + '-'*40)
        print(code[:500] + "..." if len(code) > 500 else code)

        # 4. 测试生成
        print("\n🧪 [阶段4] 测试Agent工作中...")
        tests = self.agents["test"].run(req, code, ctx)
        print("✅ 测试用例已生成\n" + '-'*40)
        print(tests[:500] + "..." if len(tests) > 500 else tests)

        # 5. 审查与闭环反馈（模拟改进循环）
        print("\n🔍 [阶段5] 审查Agent工作中...")
        issues = self.agents["review"].run(ctx)
        print("✅ 审查完成，发现问题：")
        for issue in issues[:5]:
            print(f"  - {issue}")

        # 如果发现严重问题，触发局部修复（由代码Agent重新生成相关部分）
        if any("严重" in issue for issue in issues):
            print("\n⚠️ 发现严重问题，启动修复流程...")
            fix_prompt = f"审查发现如下问题：\n{chr(10).join(issues)}\n请修复上述问题，只输出修正后的代码段。"
            fixed_code = self.agents["codegen"].call_llm(fix_prompt, ctx)
            ctx.code = fixed_code
            # 修复后重新测试
            tests2 = self.agents["test"].run(ctx.requirement_doc, fixed_code, ctx)
            ctx.test_cases = tests2
            print("🔄 代码已修复并重新生成测试用例。")

        # 汇总 Token 消耗
        print("\n" + "="*60)
        print(f"📊 全流程总计消耗 Token: {ctx.total_tokens}")
        print("📄 最终交付物：需求文档、架构设计、代码、测试用例")
        print("="*60)
        return ctx

# ---------- 主入口 ----------
def main():
    print("🎓 软件工程课设全流程多Agent协作助手")
    print("支持的项目类型：学生管理系统、图书借阅系统、课程论坛等")
    idea = input("请输入你的课程设计初步想法：").strip()
    if not idea:
        idea = "一个简单的学生成绩管理系统，支持教师录入成绩、学生查看成绩、生成成绩报表"
        print(f"使用默认想法：{idea}")

    controller = CollaborationController()
    controller.run_full_pipeline(idea)

if __name__ == "__main__":
    main()